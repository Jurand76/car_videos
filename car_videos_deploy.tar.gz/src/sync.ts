export type SlideTiming = {
  from: number;
  duration: number;
};

/** Czas fade-outu (czarny ekran + wyciszenie) po ostatnim slajdzie. */
export const OUTRO_DURATION_SECONDS = 2;

/** Dodatkowy czas na ostatnim slajdzie zanim zacznie się outro. */
export const LAST_SLIDE_TAIL_SECONDS = 1.5;

export const MIN_BEATS_PER_SLIDE = 2;
export const MAX_BEATS_PER_SLIDE = 48;

export const clampBeats = (value: number): number =>
  Math.max(MIN_BEATS_PER_SLIDE, Math.min(MAX_BEATS_PER_SLIDE, Math.round(value)));

export const resolveSlideBeats = (
  slides: { beats?: number }[],
  defaultBeats: number,
): number[] => assignVariedBeats(slides.length, clampBeats(defaultBeats));

/** Profil tempa z panelu (beatsPerSlide). */
export const getTempoProfile = (beatsPerSlide: number) => {
  const beats = clampBeats(beatsPerSlide);
  const tempoScale = Math.max(0.2, Math.min(1, beats / 16));
  return {
    beats,
    tempoScale,
    strictRhythm: beats <= 4,
    kenBurns: beats >= 10,
    preferDynamicTransitions: beats <= 8,
    transitionMinFrames: beats <= 4 ? 4 : beats <= 8 ? 6 : 8,
    transitionMaxFrames: Math.max(6, Math.round(28 * tempoScale)),
  };
};

export const getOutroDurationFrames = (fps: number): number =>
  Math.round(OUTRO_DURATION_SECONDS * fps);

export const getLastSlideTailFrames = (fps: number): number =>
  Math.round(LAST_SLIDE_TAIL_SECONDS * fps);

const slidesEndFrame = (slideTimings: SlideTiming[]): number => {
  if (!slideTimings.length) return 0;
  const last = slideTimings[slideTimings.length - 1];
  return last.from + last.duration;
};

const totalWithOutro = (
  slideTimings: SlideTiming[],
  fps: number,
  audioDurationSeconds = 0,
): number => {
  const ideal =
    slidesEndFrame(slideTimings) +
    getLastSlideTailFrames(fps) +
    getOutroDurationFrames(fps);
  if (audioDurationSeconds > 0) {
    return Math.min(ideal, Math.round(audioDurationSeconds * fps));
  }
  return ideal;
};

export type MusicSyncInfo = {
  enabled: boolean;
  mode: "beats" | "bpm" | "duration";
  audioDurationSeconds: number;
  bpm: number | null;
  beatsPerSlide: number;
  framesPerBeat: number | null;
  beatCount?: number;
  confidence?: number;
  beatTimesSeconds?: number[];
  accentCount?: number;
  analyzer?: "essentia" | "legacy";
  cutTimesSeconds?: number[];
  slideTransitionDurations?: number[];
  /** Opóźnienie wejścia tekstu w taktach (0, 1, 2, 4, 6, 8, 10). */
  textEnterDelayBeats?: number;
  animationPhases?: import("./slideAnimation").AnimationPhases;
};

import { buildAnimationPhases } from "./slideAnimation";
import {
  pickBangStrengthForAccent,
  pickTransitionDurationForAccent,
  pickTransitionForAccent,
} from "./accentDriven";
import type { TransitionType } from "./transitions";

export const guessBeatsPerSlide = (prompt: string): number => {
  const p = prompt.toLowerCase();
  if (/szybk|dynamicz|reel|tiktok|fast|aggressive|drop/.test(p)) {
    return 8;
  }
  if (/spokoj|wolno|slow|cinematic|delikat|soft/.test(p)) {
    return 24;
  }
  return 16;
};

const VARIED_BEAT_PATTERNS: number[][] = [
  [8, 16, 24, 12, 20, 32, 10, 18],
  [24, 8, 16, 28, 12, 20, 8, 32],
  [12, 20, 8, 24, 16, 8, 28, 12],
  [16, 8, 32, 12, 24, 8, 20, 16],
  [20, 12, 8, 24, 16, 32, 8, 12],
];

/** Zróżnicowany rytm slajdów wokół bazowej wartości (np. 16 taktów). */
export const assignVariedBeats = (
  slideCount: number,
  baseBeats: number,
): number[] => {
  if (slideCount <= 0) return [];
  const scale = baseBeats / 16;
  const pattern = VARIED_BEAT_PATTERNS[slideCount % VARIED_BEAT_PATTERNS.length];
  return Array.from({ length: slideCount }, (_, i) => {
    const raw = pattern[i % pattern.length];
    return clampBeats(raw * scale);
  });
};

const fitSlideBeatsToBudget = (
  slideBeats: number[],
  beatCount: number,
): number[] => {
  const budget = Math.max(
    slideBeats.length * MIN_BEATS_PER_SLIDE,
    Math.floor(beatCount * 0.95),
  );
  const rawTotal = slideBeats.reduce((sum, b) => sum + b, 0);
  if (rawTotal <= budget) {
    return slideBeats.map(clampBeats);
  }
  const scale = budget / rawTotal;
  return slideBeats.map((b) => clampBeats(b * scale));
};

const slideBeatsRadius = (beatsForSlide: number, strictRhythm = false): number =>
  strictRhythm ? 0 : beatsForSlide <= 4 ? 1 : beatsForSlide <= 8 ? 2 : 3;

const pickBeatForSlide = (
  targetBeat: number,
  beatCursor: number,
  strengths: number[],
  beatsLength: number,
  strictRhythm: boolean,
): number => {
  const minAdvance = beatCursor + 1;
  const clampedTarget = Math.min(
    beatsLength - 1,
    Math.max(minAdvance, Math.round(targetBeat)),
  );
  if (strictRhythm) {
    return clampedTarget;
  }
  return pickBeatNearTarget(targetBeat, beatCursor, strengths, beatsLength);
};

const pickBeatNearTarget = (
  targetBeat: number,
  beatCursor: number,
  strengths: number[],
  beatsLength: number,
): number => {
  const minAdvance = beatCursor + 1;
  const clampedTarget = Math.min(
    beatsLength - 1,
    Math.max(minAdvance, Math.round(targetBeat)),
  );
  const radius = slideBeatsRadius(clampedTarget - beatCursor);
  const minBeat = Math.max(minAdvance, clampedTarget - radius);
  const maxBeat = Math.min(beatsLength - 1, clampedTarget + radius);

  let bestBeat = clampedTarget;
  let bestScore = -Infinity;
  for (let beatIndex = minBeat; beatIndex <= maxBeat; beatIndex++) {
    const closenessPenalty = Math.abs(beatIndex - targetBeat) * 0.35;
    const score = (strengths[beatIndex] ?? 0.4) - closenessPenalty;
    if (score > bestScore) {
      bestScore = score;
      bestBeat = beatIndex;
    }
  }
  return Math.max(minAdvance, bestBeat);
};

export const computeMusicSync = (params: {
  slideCount: number;
  fps: number;
  audioDurationSeconds: number;
  bpm: number | null;
  beatsPerSlide: number;
}): {
  slideTimings: SlideTiming[];
  transitionDuration: number;
  slideDuration: number;
  totalDurationFrames: number;
  sync: MusicSyncInfo;
} => {
  const totalFrames = Math.round(params.audioDurationSeconds * params.fps);
  const slideCount = params.slideCount;

  if (slideCount <= 0) {
    return {
      slideTimings: [],
      transitionDuration: 20,
      slideDuration: 90,
      totalDurationFrames: 0,
      sync: {
        enabled: false,
        mode: "duration",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: null,
        beatsPerSlide: params.beatsPerSlide,
        framesPerBeat: null,
      },
    };
  }

  if (slideCount === 1) {
    const framesPerBeat =
      params.bpm && params.bpm > 0
        ? Math.round((60 / params.bpm) * params.fps)
        : Math.round((60 / 120) * params.fps);
    const segment = Math.max(1, params.beatsPerSlide) * framesPerBeat;
    const slideTimings = [{ from: 0, duration: segment }];
    return {
      slideTimings,
      transitionDuration: 0,
      slideDuration: segment,
      totalDurationFrames: totalWithOutro(slideTimings, params.fps, params.audioDurationSeconds),
      sync: {
        enabled: true,
        mode: params.bpm ? "bpm" : "duration",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: params.bpm,
        beatsPerSlide: params.beatsPerSlide,
        framesPerBeat: params.bpm ? framesPerBeat : null,
      },
    };
  }

  if (params.bpm && params.bpm > 0) {
    const framesPerBeat = Math.round((60 / params.bpm) * params.fps);
    let beatsPerSlide = Math.max(1, params.beatsPerSlide);
    const transitionDuration = Math.max(
      6,
      Math.min(Math.round(0.5 * framesPerBeat), 24),
    );

    const totalForBeats = (beats: number) => {
      const segment = beats * framesPerBeat;
      return (slideCount - 1) * (segment - transitionDuration) + segment;
    };

    while (beatsPerSlide > 1 && totalForBeats(beatsPerSlide) > totalFrames) {
      beatsPerSlide--;
    }

    const segment = beatsPerSlide * framesPerBeat;
    const slideTimings: SlideTiming[] = [];

    for (let i = 0; i < slideCount; i++) {
      const from =
        i === 0
          ? 0
          : slideTimings[i - 1].from +
            slideTimings[i - 1].duration -
            transitionDuration;
      slideTimings.push({ from, duration: segment });
    }

    return {
      slideTimings,
      transitionDuration,
      slideDuration: segment,
      totalDurationFrames: totalWithOutro(slideTimings, params.fps, params.audioDurationSeconds),
      sync: {
        enabled: true,
        mode: "bpm",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: params.bpm,
        beatsPerSlide,
        framesPerBeat,
      },
    };
  }

  const transitionDuration = Math.max(
    8,
    Math.min(Math.round(totalFrames / slideCount / 7), 28),
  );
  const framesPerBeat = Math.round((60 / 120) * params.fps);
  const slideDuration = Math.max(72, params.beatsPerSlide * framesPerBeat);

  const slideTimings: SlideTiming[] = [];
  for (let i = 0; i < slideCount; i++) {
    const from =
      i === 0
        ? 0
        : slideTimings[i - 1].from +
          slideTimings[i - 1].duration -
          transitionDuration;
    slideTimings.push({ from, duration: slideDuration });
  }

  return {
    slideTimings,
    transitionDuration,
    slideDuration,
    totalDurationFrames: totalWithOutro(slideTimings, params.fps, params.audioDurationSeconds),
    sync: {
      enabled: true,
      mode: "duration",
      audioDurationSeconds: params.audioDurationSeconds,
      bpm: null,
      beatsPerSlide: params.beatsPerSlide,
      framesPerBeat: null,
    },
  };
};

export const formatDuration = (seconds: number): string => {
  const m = Math.floor(seconds / 60);
  const s = Math.round(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
};

export const computeBeatSync = (params: {
  slideCount: number;
  fps: number;
  audioDurationSeconds: number;
  beatTimesSeconds: number[];
  slideBeats: number[];
  bpm: number;
}): {
  slideTimings: SlideTiming[];
  transitionDuration: number;
  slideDuration: number;
  totalDurationFrames: number;
  sync: MusicSyncInfo;
} => {
  const slideCount = params.slideCount;
  const beats = params.beatTimesSeconds.filter(
    (t) => t <= params.audioDurationSeconds + 0.001,
  );

  if (slideCount <= 0) {
    return {
      slideTimings: [],
      transitionDuration: 20,
      slideDuration: 90,
      totalDurationFrames: 0,
      sync: {
        enabled: false,
        mode: "beats",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: params.bpm,
        beatsPerSlide: params.slideBeats[0] ?? 16,
        framesPerBeat: null,
        beatCount: 0,
      },
    };
  }

  if (slideCount === 1) {
    const beatIntervalSeconds =
      beats.length > 1 ? beats[1] - beats[0] : 60 / params.bpm;
    const getBeatTime = (beatIndex: number) => {
      if (beatIndex < beats.length) return beats[beatIndex];
      const lastBeat = beats[beats.length - 1] ?? 0;
      return lastBeat + (beatIndex - beats.length + 1) * beatIntervalSeconds;
    };
    const slideBeats = clampBeats(params.slideBeats[0] ?? 16);
    const duration = Math.max(
      1,
      Math.round(getBeatTime(slideBeats) * params.fps),
    );
    const slideTimings = [{ from: 0, duration }];
    return {
      slideTimings,
      transitionDuration: 0,
      slideDuration: duration,
      totalDurationFrames: totalWithOutro(slideTimings, params.fps, params.audioDurationSeconds),
      sync: {
        enabled: true,
        mode: "beats",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: params.bpm,
        beatsPerSlide: slideBeats,
        framesPerBeat: Math.round(beatIntervalSeconds * params.fps),
        beatCount: beats.length,
      },
    };
  }

  const beatIntervalSeconds =
    beats.length > 1 ? beats[1] - beats[0] : 60 / params.bpm;
  const transitionDuration = Math.max(
    6,
    Math.min(Math.round(0.45 * beatIntervalSeconds * params.fps), 22),
  );

  const getBeatTime = (beatIndex: number) => {
    if (beatIndex < beats.length) {
      return beats[beatIndex];
    }
    const lastBeat = beats[beats.length - 1] ?? 0;
    return lastBeat + (beatIndex - beats.length + 1) * beatIntervalSeconds;
  };

  let slideBeats = params.slideBeats.map(clampBeats);
  if (slideBeats.length < slideCount) {
    const fallback = Math.round(
      slideBeats.reduce((sum, b) => sum + b, 0) / Math.max(slideBeats.length, 1),
    ) || 16;
    while (slideBeats.length < slideCount) {
      slideBeats.push(fallback);
    }
  }

  slideBeats = slideBeats.slice(0, slideCount);
  slideBeats = fitSlideBeatsToBudget(slideBeats, beats.length);

  const cutTimes: number[] = [0];
  let beatCursor = 0;
  for (let i = 0; i < slideCount - 1; i++) {
    beatCursor += slideBeats[i];
    cutTimes.push(getBeatTime(beatCursor));
  }

  const avgBeats = Math.round(
    slideBeats.reduce((sum, b) => sum + b, 0) / slideCount,
  );

  const slideTimings: SlideTiming[] = [];
  for (let i = 0; i < slideCount; i++) {
    const from =
      i === 0
        ? 0
        : Math.max(
            0,
            Math.round(cutTimes[i] * params.fps) - transitionDuration,
          );
    const endFrame =
      i === slideCount - 1
        ? Math.round(getBeatTime(beatCursor + slideBeats[slideCount - 1]) * params.fps)
        : Math.round(cutTimes[i + 1] * params.fps);
    slideTimings.push({
      from,
      duration: Math.max(endFrame - from, transitionDuration + 1),
    });
  }

  const avgDuration = Math.round(
    slideTimings.reduce((sum, t) => sum + t.duration, 0) / slideCount,
  );

  return {
    slideTimings,
    transitionDuration,
    slideDuration: avgDuration,
    totalDurationFrames: totalWithOutro(slideTimings, params.fps, params.audioDurationSeconds),
      sync: {
        enabled: true,
        mode: "beats",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: params.bpm,
        beatsPerSlide: avgBeats,
        framesPerBeat: Math.round(beatIntervalSeconds * params.fps),
        beatCount: beats.length,
        beatTimesSeconds: beats,
        animationPhases: buildAnimationPhases(avgBeats),
      },
  };
};

export const computeAccentSync = (params: {
  slideCount: number;
  fps: number;
  audioDurationSeconds: number;
  beatTimesSeconds: number[];
  beatStrengths: number[];
  slideBeats: number[];
  bpm: number;
  analyzer?: "essentia" | "legacy";
  confidence?: number;
  allowedTransitions?: TransitionType[];
}): {
  slideTimings: SlideTiming[];
  transitionDuration: number;
  slideDuration: number;
  totalDurationFrames: number;
  slideAccentStrengths: number[];
  slideTransitions: (TransitionType | undefined)[];
  slideTransitionDurations: number[];
  sync: MusicSyncInfo;
} => {
  const slideCount = params.slideCount;
  const beats = params.beatTimesSeconds.filter(
    (t) => t >= 0 && t <= params.audioDurationSeconds + 0.05,
  );
  const strengths =
    params.beatStrengths.length === beats.length
      ? params.beatStrengths
      : beats.map(() => 0.4);

  if (slideCount <= 0) {
    return {
      slideTimings: [],
      transitionDuration: 20,
      slideDuration: 90,
      totalDurationFrames: 0,
      slideAccentStrengths: [],
      slideTransitions: [],
      slideTransitionDurations: [],
      sync: {
        enabled: false,
        mode: "beats",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: params.bpm,
        beatsPerSlide: params.slideBeats[0] ?? 16,
        framesPerBeat: null,
        beatCount: 0,
        analyzer: params.analyzer,
      },
    };
  }

  if (slideCount === 1) {
    const beatIntervalSeconds =
      beats.length > 1 ? beats[1] - beats[0] : 60 / params.bpm;
    const getBeatTimeAtIndex = (beatIndex: number) => {
      if (beatIndex < beats.length) return beats[beatIndex];
      const lastBeat = beats[beats.length - 1] ?? 0;
      return lastBeat + (beatIndex - beats.length + 1) * beatIntervalSeconds;
    };
    const slideBeats = clampBeats(params.slideBeats[0] ?? 16);
    const duration = Math.max(
      1,
      Math.round(getBeatTimeAtIndex(slideBeats) * params.fps),
    );
    const slideTimings = [{ from: 0, duration }];
    return {
      slideTimings,
      transitionDuration: 0,
      slideDuration: duration,
      totalDurationFrames: totalWithOutro(slideTimings, params.fps, params.audioDurationSeconds),
      slideAccentStrengths: [strengths[0] ?? 0.4],
      slideTransitions: [undefined],
      slideTransitionDurations: [0],
      sync: {
        enabled: true,
        mode: "beats",
        audioDurationSeconds: params.audioDurationSeconds,
        bpm: params.bpm,
        beatsPerSlide: slideBeats,
        framesPerBeat: Math.round(beatIntervalSeconds * params.fps),
        beatCount: beats.length,
        beatTimesSeconds: beats,
        accentCount: strengths.filter((s) => s >= 0.55).length,
        analyzer: params.analyzer,
        confidence: params.confidence,
      },
    };
  }

  const beatIntervalSeconds =
    beats.length > 1 ? beats[1] - beats[0] : 60 / params.bpm;
  const defaultTransitionDuration = Math.max(
    8,
    Math.min(Math.round(0.45 * beatIntervalSeconds * params.fps), 24),
  );

  let slideBeats = fitSlideBeatsToBudget(
    params.slideBeats.map(clampBeats),
    beats.length,
  );
  while (slideBeats.length < slideCount) {
    slideBeats.push(slideBeats[slideBeats.length - 1] ?? 16);
  }
  slideBeats = slideBeats.slice(0, slideCount);

  const avgBeats =
    slideBeats.reduce((sum, b) => sum + b, 0) / Math.max(slideCount, 1);
  const tempo = getTempoProfile(Math.round(avgBeats));

  const cutTimes: number[] = [0];
  const cutBeatIndices: number[] = [0];
  let beatCursor = 0;

  for (let slideIndex = 0; slideIndex < slideCount - 1; slideIndex++) {
    const idealBeat = beatCursor + slideBeats[slideIndex];
    beatCursor = pickBeatForSlide(
      idealBeat,
      beatCursor,
      strengths,
      beats.length,
      tempo.strictRhythm,
    );
    cutTimes.push(beats[beatCursor]);
    cutBeatIndices.push(beatCursor);
  }

  const getBeatTimeAtIndex = (beatIndex: number) => {
    if (beatIndex < beats.length) return beats[beatIndex];
    const lastBeat = beats[beats.length - 1] ?? 0;
    return lastBeat + (beatIndex - beats.length + 1) * beatIntervalSeconds;
  };

  const slideAccentStrengths: number[] = [];
  const slideTransitions: (TransitionType | undefined)[] = [];
  const slideTransitionDurations: number[] = [];
  const slideTimings: SlideTiming[] = [];

  for (let i = 0; i < slideCount; i++) {
    const enterStrength =
      i === 0 ? 0.4 : strengths[cutBeatIndices[i]] ?? 0.45;
    const exitStrength =
      i < slideCount - 1
        ? strengths[cutBeatIndices[i + 1]] ?? 0.45
        : enterStrength;
    slideAccentStrengths.push(exitStrength);

    const framesPerBeat = Math.round(beatIntervalSeconds * params.fps);
    let transitionDuration =
      i === slideCount - 1
        ? 0
        : pickTransitionDurationForAccent(exitStrength, framesPerBeat);
    if (i < slideCount - 1) {
      transitionDuration = Math.max(
        tempo.transitionMinFrames,
        Math.min(
          tempo.transitionMaxFrames,
          Math.round(transitionDuration * tempo.tempoScale),
        ),
      );
    }
    slideTransitionDurations.push(transitionDuration);

    const transitionStrength = tempo.preferDynamicTransitions
      ? Math.max(exitStrength, 0.68)
      : exitStrength;
    slideTransitions.push(
      i === 0
        ? undefined
        : pickTransitionForAccent(
            transitionStrength,
            i - 1,
            params.allowedTransitions,
          ),
    );

    const enterOverlap =
      i === 0 ? 0 : slideTransitionDurations[i - 1] ?? transitionDuration;
    const from =
      i === 0
        ? 0
        : Math.max(0, Math.round(cutTimes[i] * params.fps) - enterOverlap);
    const endFrame =
      i === slideCount - 1
        ? Math.round(
            getBeatTimeAtIndex(
              (cutBeatIndices[slideCount - 1] ?? 0) + slideBeats[slideCount - 1],
            ) * params.fps,
          )
        : Math.round(cutTimes[i + 1] * params.fps);
    slideTimings.push({
      from,
      duration: Math.max(endFrame - from, enterOverlap + 1),
    });
  }

  const avgBeatsRounded = Math.round(avgBeats);
  const avgDuration = Math.round(
    slideTimings.reduce((sum, t) => sum + t.duration, 0) / slideCount,
  );
  const durations = slideTransitionDurations.filter((value) => value > 0);
  const avgTransition = durations.length
    ? Math.round(durations.reduce((sum, value) => sum + value, 0) / durations.length)
    : defaultTransitionDuration;

  return {
    slideTimings,
    transitionDuration: avgTransition,
    slideDuration: avgDuration,
    totalDurationFrames: totalWithOutro(slideTimings, params.fps, params.audioDurationSeconds),
    slideAccentStrengths,
    slideTransitions,
    slideTransitionDurations,
    sync: {
      enabled: true,
      mode: "beats",
      audioDurationSeconds: params.audioDurationSeconds,
      bpm: params.bpm,
      beatsPerSlide: avgBeatsRounded,
      framesPerBeat: Math.round(beatIntervalSeconds * params.fps),
      beatCount: beats.length,
      beatTimesSeconds: beats,
      accentCount: strengths.filter((s) => s >= 0.55).length,
      analyzer: params.analyzer ?? "essentia",
      confidence: params.confidence,
      cutTimesSeconds: cutTimes,
      animationPhases: {
        ...buildAnimationPhases(avgBeatsRounded),
        bangStrength: pickBangStrengthForAccent(
          slideAccentStrengths.reduce((max, s) => Math.max(max, s), 0.4),
        ),
      },
    },
  };
};
